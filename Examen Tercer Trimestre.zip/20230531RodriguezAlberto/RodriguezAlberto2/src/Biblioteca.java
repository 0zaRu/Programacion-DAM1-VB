import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class Biblioteca {

	//Instanciación del teclado y constantes del menú
	static Scanner kb = new Scanner(System.in);
	static final int INSERTAR = 1;
	static final int ELIMINAR = 2;
	static final int CONSULTA = 3;
	static final int CONSULTA_TODO = 4;
	static final int SALIR = 5;
	
	//Numero de lineas a mover cuando se llame a limpiaPantalla
	static final int LINEAS = 30;
	/**
	 * Método main que crea un HashMap de Libros, y 4 libros de ejemplo para su uso
	 * */
	public static void main(String[] args) {
		//Creamos algunos libros para cargar en el hashMap a modo de ejemplo
		Libro libro1 = new Libro("El camino de los reyes", "Brandom Sanderson", 1200, 14.8f);
		Libro libro2 = new Libro("Palabras Radiantes", "Brandom Sanderson", 1400, 15.8f);
		Libro libro3 = new Libro("Juramentada", "Brandom Sanderson", 1500, 16.9f);
		Libro libro4 = new Libro("El ritmo de la guerra", "Brandom Sanderson", 1600, 15.9f);
		
		//Creamos el HashMap con los libros de ejemplo
		HashMap<String, Libro> biblioteca = new HashMap<String, Libro>();
		biblioteca.put("AT1", libro1);
		biblioteca.put("AT2", libro2);
		biblioteca.put("AT3", libro3);
		biblioteca.put("AT4", libro4);
		
		//Menu selector para las funcionalidades del programa
		boolean salir = false;
		do {
			limpiaPantalla();
			
			switch(menuOpciones()) {
			case INSERTAR:
				limpiaPantalla();
				//1. insercción sencilla
				insertaLibro(biblioteca);
				kb.nextLine();
				break;
			
			case ELIMINAR:
				limpiaPantalla();
				//2. Eliminar desde la referencia
				eliminaPorRef(biblioteca);
				kb.nextLine();
				break;
				
			case CONSULTA:
				limpiaPantalla();
				//3. Consultar por referencia
				consultaPorRef(biblioteca);
				kb.nextLine();
				break;
				
			case CONSULTA_TODO:
				limpiaPantalla();
				//4. Listado general
				listarBiblio(biblioteca);
				kb.nextLine();
				break;
				
			case SALIR:
				salir = true;
				break;
			
			default:
				limpiaPantalla();
				System.out.println("\nOpcion introducida incorrecta.");
				kb.nextLine();
				
			}
			
		}while(!salir);
		
		System.out.println("\nSe ha salido del programa.");
		kb.close();
	}
	
	/**
	 * Método que muestra las opciones del programa y devuelve la opcion seleccionada
	 * */
	public static int menuOpciones() {
		System.out.println("OPCIONES:");
		System.out.println("==============================");
		System.out.println(INSERTAR+". Agrega un libro");
		System.out.println(ELIMINAR+". Elimina un libro");
		System.out.println(CONSULTA+". Consultar un libro desde su referencia");
		System.out.println(CONSULTA_TODO+". Consultar todos los libros");
		System.out.println(SALIR+". Salir del programa");
		System.out.println("============================================");
		System.out.print("\nOpcion: ");
		int opcion = kb.nextInt();
		return opcion;
	}
	
	/**
	 * Método que inserta un Libro a la biblioteca del main
	 * @param HasMap<String, Libro> biblioteca: Contiene todos los libros
	 * @return void
	 * */
	public static void insertaLibro(HashMap<String, Libro> biblioteca) {
		kb.nextLine();
		
		//Pedimos todos los valores, comprobamos que la referencia no existe todavía, y añadimos un objeto Libro nuevo
		System.out.print("Introduce los datos para un nuevo libro: \nTitulo: ");
		String titulo = kb.nextLine();
		
		System.out.print("\nintroduce su autor: ");
		String autor = kb.nextLine();
		
		System.out.print("\nIntroduce cuantas páginas tiene: ");
		int paginas = kb.nextInt();
		
		System.out.println("\nIntroduce su precio en euros(, como separador): ");
		float precio = kb.nextFloat();
		kb.nextLine();
		
		boolean validKey = false;
		String referencia = null;
		
		//Bucle comprobatorio de que la referencia no existe
		while(!validKey) {
			System.out.print("\nPor ultimo introduce una referencia para el: ");
			referencia = kb.nextLine();
			
			if(biblioteca.containsKey(referencia))
				System.out.println("La referencia introducida no es correcta ...\n");
			else
				validKey = true;
		}
		biblioteca.put(referencia.toUpperCase(), new Libro(titulo, autor, paginas, precio));
		System.out.println("\nSe ha insertado con la referencia "+referencia+":\n"+biblioteca.get(referencia));
	}
	
	/**
	 * Método que elimina un Libro de la biblioteca del main en funcion de su referencia
	 * @param HasMap<String, Libro> biblioteca: Contiene todos los libros
	 * @return void
	 * */
	public static void eliminaPorRef(HashMap<String, Libro> biblioteca) {
		kb.nextLine();
		
		//Se pide la referencia
		System.out.print("\nIntroduce la referencia del libro que deseas eliminar: ");
		String ref = kb.nextLine();
		
		//Se comprueba si existe, si es así, se elimina, si no se dice que no se ha encontrado nada
		if(biblioteca.containsKey(ref.toUpperCase())) {
			Libro borrado = biblioteca.remove(ref);
			System.out.println("\nSe ha eliminado el libro con la referencia "+ref+":\n"+borrado);
		}
		else
			System.out.println("\nNo se ha encontrado ningun libro con esa referencia");
	}
	
	/**
	 * Método que consulta un Libro de la biblioteca del main en funcion de la referencia
	 * @param HasMap<String, Libro> biblioteca: Contiene todos los libros
	 * @return void
	 * */
	public static void consultaPorRef(HashMap<String, Libro> biblioteca) {
		kb.nextLine();
		
		//Se pide la referencia
		System.out.print("\nIntroduce la referencia del libro que deseas encontrar: ");
		String ref = kb.nextLine();
		
		//Se comprueba si existe, si es así se muestra y si no no pasa nada
		if(biblioteca.containsKey(ref.toUpperCase())) {
			System.out.println("\nCon la referencia "+ref+", se ha encontrado el siguiente libro:\n"+biblioteca.get(ref));
		}
		else
			System.out.println("\nNo se ha encontrado ningun libro con esa referencia");
	}
	
	/**
	 * Método que lista todos los libros de la biblioteca del main
	 * @param HasMap<String, Libro> biblioteca: Contiene todos los libros
	 * @return void
	 * */
	public static void listarBiblio(HashMap<String, Libro> biblioteca) {
		kb.nextLine();
		
		//Estoy bastante seguro de que la intención era usar entrySet pero he optado por esta forma 
		
		//Paso los valores de la biblioteca a un array
		Collection<Libro> libros = biblioteca.values();
		Object arrayLibros[] = libros.toArray();
		
		//Paso las referencias de la biblioteca a un array
		Set<String> keys = biblioteca.keySet(); 
		Object arrayKeys[] = keys.toArray();
		
		//enunciado
		System.out.println(" \nListado de todos los libros: ");
		System.out.println("==============================");
		
		//Muestro las referencias y libros en buble parametruzando los arrays de Object[]
		for(int i=0; i <arrayLibros.length; i++) {

			System.out.println("Referencia "+(String)arrayKeys[i]+": "+(Libro)arrayLibros[i]);
		}
		System.out.println("\nPuse enter para continuar ...");

	}
	
	/**
	 * Metodo para simular un limpiado de pantalla
	 * */
	public static void limpiaPantalla() {
		for(int i = 0; i < LINEAS; i++) {
			System.out.println();
		}
	}
}
