//Código de Alberto Rodríguez Pérez			alberto.rodper.2@educa.jcyl.es

import java.util.ArrayList;

public class Principal {
	public static void main(String[] args) {
		/*
		//Inserción de un alumno
		if(Alumno.inserta("Carlos", "Sánchez", 2021) == 1)
			System.out.println("Alumno insertado correctamente");
		else
			System.out.println("No se pudo insertar al alumno indicado");

		//Actualizacion de los datos de un alumno
		if(Alumno.actualiza(9, "Carlitos", "Sánchez", 2022) == 1)
			System.out.println("Alumno modificado correctamente");
		else
			System.out.println("No se pudo modificar al alumno");
				
		//Inserción de un alumno
		if(Alumno.elimina(2) == 1)
			System.out.println("Alumno eliminado correctamente");
		else
			System.out.println("No se pudo eliminar al alumno indicado");
		
		*/
		
		//Consulta de los alumnos existentes con el nuevo método (facilitar veracidad de los resultados del GUI)
		ArrayList<Alumno> alumnos = Alumno.consulta("ru");
		for(int i =0; i< alumnos.size(); i++)
			System.out.println(alumnos.get(i));

		
		JFrameConsulta consultaGUI = new JFrameConsulta();
		consultaGUI.setVisible(true);
		
	}
}
