//Código de Alberto Rodríguez Pérez			alberto.rodper.2@educa.jcyl.es

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

/**
 * Clase tipo JFrame que implementa ActionListener, crea una ventana para ver una tabla de alumnos en funcion de un buscador
 * */
public class JFrameConsulta extends JFrame implements ActionListener{
	
	private static final long serialVersionUID = 1;
	
	//Objetos como atributo por su utilización desde métodos de la clase
	protected JTextField buscador;
	protected JTable tablaConsul;
	protected JScrollPane scrollContent;
	
	public JFrameConsulta() {
		//Creamos los parámetros iniciales del JFrame con Layout tipo BorderLayout
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		}catch(Exception e) {
			e.getStackTrace();
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		//Empezamos con la instanciación de las partes de la ventana
		//NORTE
		add(new JLabel("CONSULTA DE ALUMNOS", SwingConstants.CENTER), BorderLayout.NORTH);
				
		
		//SUR (PANEL BUSQUEDA)
		JPanel panelFind = new JPanel(new FlowLayout());
		panelFind.add(new JLabel("Alumnos cuyo apellido contenga ..."));
		
		buscador = new JTextField(20);
		panelFind.add(buscador);
		
		JButton consultar = new JButton("Consultar");
		consultar.addActionListener(this);
		panelFind.add(consultar);
		
		//Añadimos al sur el panel contenedor del panel, textfield y button
		add(panelFind, BorderLayout.SOUTH);
		
		
		//Otros parámetros de la ventana
		setTitle("Consulta de alumnos");
		setSize(600, 100);
		setLocation(500, 300);
	}
	
	/*
	*@Override
	*Metodo implementado por ActionListener al que se llega solo cuando se pulse el botón de consulta
	*Añade el scrollpane con la tabla al centro del JFrame
	**/
	public void actionPerformed(ActionEvent e) {
		//Cuando se pulsa el botón y se pasa por actionPerformed:
		//Creación de array de alumnos consultados en función del texto del jtextfield
		ArrayList<Alumno> alumnosAL = Alumno.consulta(buscador.getText());
		
		//Creamos la matriz de objetos que pasaremos a la tabla de consultas
		Object[][] alumnos = new Object[alumnosAL.size()][3];
		
		//Rellenamos la matriz con el arraylist
		for(int i = 0; i < alumnosAL.size(); i++) {
			alumnos[i][0] = alumnosAL.get(i).getNombre();
			alumnos[i][1] = alumnosAL.get(i).getApellido();
			alumnos[i][2] = alumnosAL.get(i).getAnho_Ingreso();
		}
		
		//Creamos la tabla con los datos
		tablaConsul = new JTable(alumnos, new String[] {"Nombre", "Apellido", "Año de ingreso"});
		
		//Se la añadimos al scrollpane, y esto lo añadimos al centro del JFrame
		scrollContent = new JScrollPane(tablaConsul);
		add(scrollContent, BorderLayout.CENTER);
		
		//Actualizamos la ventana para que aparezcan representados
		pack();
	}
}
