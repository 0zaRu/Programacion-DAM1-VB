//Código de Alberto Rodríguez Pérez			alberto.rodper.2@educa.jcyl.es

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ResourceBundle;

public class UConnection {
	private static Connection con = null;
	
	public static Connection getConection() {
		try {
			if(con == null) {
				Runtime.getRuntime().addShutdownHook(new MiShutdownHook());
				
				ResourceBundle rb = ResourceBundle.getBundle("jdbc");
				
				String driver = rb.getString("driver");
				String url = rb.getString("url");
				String usr = rb.getString("usr");
				String pwd = rb.getString("pwd");
				
				Class.forName(driver);
				con = DriverManager.getConnection(url, usr, pwd);
			}
			return con;
			
		}catch(Exception e) {
			throw new RuntimeException("Error estableciendo la conexion\n\n\n\n\n"+ e.getMessage());
		}
	}
	
	static class MiShutdownHook extends Thread {
		@Override
		public void run() {
			try {
				con = UConnection.getConection();
				con.close();
			}catch(Exception e) {
				throw new RuntimeException(e);
			}
		}
	}
}