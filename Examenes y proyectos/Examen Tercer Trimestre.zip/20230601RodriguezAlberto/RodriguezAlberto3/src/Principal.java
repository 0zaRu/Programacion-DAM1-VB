//Código de Alberto Rodríguez Pérez			alberto.rodper.2@educa.jcyl.es

import java.util.ArrayList;

public class Principal {
	public static void main(String[] args) {
		//Inserción de un alumno
		if(Alumno.inserta("Carlos", "Sánchez", 2021) == 1)
			System.out.println("Alumno insertado correctamente");
		else
			System.out.println("No se pudo insertar al alumno indicado");
		
		//Consulta de los alumnos existentes
		ArrayList<Alumno> alumnos = Alumno.consulta();
		for(int i =0; i< alumnos.size(); i++)
			System.out.println(alumnos.get(i));
		
		//Actualizacion de los datos de un alumno
		if(Alumno.actualiza(7, "Carlitos", "Sánchez", 2022) == 1)
			System.out.println("Alumno modificado correctamente");
		else
			System.out.println("No se pudo modificar al alumno");
				
		//Inserción de un alumno
		//Recuerda modificar la id cada vez, pues no se repiten en nuevas insercciones, solo se podrá borrar la ID=n una vez
		if(Alumno.elimina(16) == 1)
			System.out.println("Alumno eliminado correctamente");
		else
			System.out.println("No se pudo eliminar al alumno indicado");
		
	}
}
