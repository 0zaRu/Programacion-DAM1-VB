//Código de Alberto Rodríguez Pérez			alberto.rodper.2@educa.jcyl.es

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Clase alumno con todos los getters, aunque estos no han sido utilizados pero para facilitar futuras modificaciones y mantenimiento
 * */
public class Alumno {
	
	//Atributos privados para favorecer la ocultacíon
	private String nombre;
	private String apellido;
	private int anho_ingreso;
	private int id;
	
	/**
	 * Constructor para alumnos sin asignar id(pues eso lo hace la base de datos)
	 * */
	Alumno(String nombre, String apellido, int anho_ingreso){
		this.nombre = nombre;
		this.apellido = apellido;
		this.anho_ingreso = anho_ingreso;
	}
	
	/**
	 * Constructor con asignación de id, para recuperar alumnos de la base de datos
	 * */
	Alumno(int id, String nombre, String apellido, int anho_ingreso){
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.anho_ingreso = anho_ingreso;
	}
	
	/**
	 * Método inserta, recibe por parámetros los valores del nuevo alumno y lo añade haciendo uso de la conexión
	 * */
	public static int inserta(String nombre, String apellido, int anho_ingreso) {
		//Recogemos o creamos la conexión através de Singleton Pattern
		Connection con = UConnection.getConection();
		
		//Instanciación de la sentencia preparada externa para su cierra en finally
		PreparedStatement pstm = null;
		int resultado = 0;
		
		String sql = "INSERT INTO alumnos(NOMBRE, APELLIDO, AÑO) VALUES(?, ?, ?)";
		try {
			
			//Establecemos la sentencia sql
			pstm = con.prepareStatement(sql);
			
			//Desparametrizamos
			pstm.setString(1, nombre);
			pstm.setString(2, apellido);
			pstm.setInt(3, anho_ingreso);
			
			//almacenamos el resultado
			resultado = pstm.executeUpdate();
			
		}catch(SQLException e) {
			System.err.println("Error en la insercción");
		}
		finally {
			try {
				pstm.close();
			}catch(SQLException e) {
				System.err.println("Error de cierre de pstm");
			}
		}
		return resultado;
	}
	
	/**
	 * Metodo de consulta que devuelve todos los alumnos de la base de datos en un ArrayList parametrizado a Alumno
	 * */
	public static ArrayList<Alumno> consulta(){
		//Recogemos o creamos la conexión através de Singleton Pattern
		Connection con = UConnection.getConection();
		
		ArrayList<Alumno> alumnos = new ArrayList<Alumno>();
		
		//Instanciación externa para su cierra en finally
		ResultSet rs = null;
		PreparedStatement pstm = null;
		
		String sql = "SELECT IDALUMNOS, NOMBRE, APELLIDO, AÑO FROM alumnos";
		try {
			//ejecutamos la sentencia y recogemos el resultado
			pstm = con.prepareStatement(sql);
			rs = pstm.executeQuery();

			//Almacenamos el resultado en el ArrayList
			while(rs.next()) {
				alumnos.add(new Alumno(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4)));
			}
			
		}catch(SQLException e) {
			System.err.println("Error en la consulta");
		}
		finally {
			try {
				pstm.close();
				rs.close();
			}catch(SQLException e){
				System.err.println("Error de cierre de pstm o rs");
			}
		}
		
		//Devolvemos el ArrayList
		return alumnos;
	}
	
	/**
	 * Metodo actualiza que recibe la id a comprobar y los datos nuevos para la fila asociada a esta id
	 * */
	public static int actualiza(int id, String nombre, String apellido, int anho_ingreso) {
		//Recogemos o creamos la conexión através de Singleton Pattern
		Connection con = UConnection.getConection();
		
		//Instanciación externa para su cierre en finally
		PreparedStatement pstm = null;
		
		int resultado = 0;
		//Construcción de la dencia sql
		String sql = "UPDATE Alumnos SET Nombre=?, Apellido=?, Año=? ";
		sql += "WHERE IDALUMNOS=?";
		
		try {
			//Desparametrización y ejecución de la sentencia preparada
			pstm = con.prepareStatement(sql);
			pstm.setString(1, nombre);
			pstm.setString(2, apellido);
			pstm.setInt(3, anho_ingreso);
			pstm.setInt(4, id);
			
			resultado = pstm.executeUpdate();
			
		}catch(SQLException e) {
			System.err.println("Error en la actualización");
		}
		finally {
			try {
				pstm.close();
			}catch(SQLException e) {
				System.err.println("Error en el cierra de pstm");
			}
		}
		return resultado;
	}
	
	/**
	 * Metodo elimina que busca y borra en función de la id que recibe por parámetro
	 * */
	public static int elimina(int id) {
		//Recogemos o creamos la conexión através de Singleton Pattern
		Connection con = UConnection.getConection();
		
		//Instanciación externa para su cierre en el finally
		PreparedStatement pstm = null;
		
		int resultado = 0;
		//creacion de la sentencia sql
		String sql = "DELETE FROM alumnos ";
		sql += "WHERE IDALUMNOS=?";
		
		try {
			
			//ejecución y desparametrización
			pstm = con.prepareStatement(sql);
			pstm.setInt(1, id);
			
			resultado = pstm.executeUpdate();
			
		}catch(SQLException e) {
			System.err.println("Error en la eliminación");
		}
		finally {
			try {
				pstm.close();
			}catch(SQLException e) {
				System.err.println("Error cerrando pstm");
			}
		}
		return resultado;
	}
	
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public void setAnho_Ingreso(int anho_ingreso) {
		this.anho_ingreso = anho_ingreso;
	}
	
	public void setID(int id) {
		this.id = id;
	}
	
	/*
	*@Override
	*Metodo toString sobre escrito para facilitar la impresión de un alumno
	**/
	public String toString() {
		return "Alumno de nombre "+nombre+" "+apellido+", con ID "+id+"y ano de ingreso "+anho_ingreso;
	}
}
