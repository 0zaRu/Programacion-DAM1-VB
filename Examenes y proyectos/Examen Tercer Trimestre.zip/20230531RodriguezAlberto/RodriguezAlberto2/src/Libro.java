
public class Libro {
	
	private String titulo;
	private String autor;
	private int paginas;
	private float precio;
	
	public Libro(String titulo, String autor, int paginas, float precio){
		this.titulo = titulo;
		this.autor = autor;
		this.paginas = paginas;
		this.precio = precio;
	}
	
	public String getTitulo() {
		return this.titulo;
	}
	
	public String getAutor() {
		return this.autor;
	}
	
	public int getPaginas() {
		return this.paginas;
	}
	
	public float getPrecio() {
		return this.precio;
	}
	
	@Override
	public String toString() {
		return "El libro "+this.titulo+" escrito por "+this.autor+" tiene "+this.paginas+" paginas y cuesta "+this.precio+" euros.";
	}
	
}
