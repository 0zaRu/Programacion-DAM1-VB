import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Saludo extends JFrame implements ActionListener{
	
	private static final long serialVersionUID = 1;
	
	static final int TAM_INI = 18;
	
	//Creamos aquí el texto para que sea accesible a editar desde el actionListener
	JLabel texto = new JLabel("¡HOLA, DAM1!");
	
	/**
	 * Constructor principal de la ventana para saludar a DAM1C
	 * */
	Saludo(){
		//Establecemos el LookAndFeel del sistema operativo
		try {
		UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		}catch(Exception e) {
			e.getStackTrace();
		}
		
		//No establecemos el cierra del programa asociado al cierre de la ventana con setDefaultCloseOperation pues hay que implementar WindowListener igualmente
		//Añadimos un listener a la ventana para el panel emergente y cierre del programa
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				//Dialogo emergente de mensaje con los parámetros en el constructor
				JOptionPane.showMessageDialog(getContentPane(), "Mucha suerte", "Despedida", JOptionPane.INFORMATION_MESSAGE);
				System.exit(0);
			}
		});
		
		//Establecemos el Layout del panel principal de la ventana
		setLayout(new GridBagLayout());
		
		//Establecemos los constraits principales
		GridBagConstraints cnst = new GridBagConstraints(0, 0, 1, 1, 0, 0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0);

		//Instanciamos el botón que se usará para el cambio de color
		JButton cambiaColor = new JButton("Color de texto");
		
		//Le añadimos el Mnemónico, tooltiptext y el listener, que será esta clase, para que se habra el ChooseColor al clicar
		cambiaColor.setMnemonic('C');
		cambiaColor.setToolTipText("Cambio de color");
		cambiaColor.addActionListener(this);
		
		//Lo añadimos al panel
		add(cambiaColor, cnst);
		
		//Damos la fuente al texto central, y establecemos los cambios en los constraits
		texto.setFont(new Font("", Font.PLAIN, TAM_INI));

		cnst.gridx = 0;
		cnst.gridy = 1;

		//Lo añadimos al panel
		add(texto, cnst);
		
		//Creamos el slider que servirá para cambiar el tamaño del texto y cambiamos los sestters para su correcta visualización
		JSlider cambiaTam = new JSlider(JSlider.HORIZONTAL, 6, 60, TAM_INI);
		cambiaTam.setMajorTickSpacing(6);
		cambiaTam.setMinorTickSpacing(2);
		cambiaTam.setPaintLabels(true);
		cambiaTam.setPaintTicks(true);
		cambiaTam.setPaintTrack(true);
		
		//Añadimos el listener para que cambie la letra al respectivo valor del Slider
		cambiaTam.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				texto.setFont(new Font("", Font.PLAIN, cambiaTam.getValue()));
			}
			
		});
		
		//Damos los constraits necesarios y lo añadimos al panel
		cnst.fill = GridBagConstraints.BOTH;
		cnst.gridx = 0;
		cnst.gridy = 2;
		
		add(cambiaTam, cnst);

		//Parametros iniciales de la ventana
		setLocation(500, 500);
		setSize(600, 200);
		setTitle("Saludo");
	}
	
	/*
	*Método de actionListener de la clase (se podría haber puesto en el botón pero así había variedad)
	*@Override
	**/
	public void actionPerformed(ActionEvent e) {
		Color selected = JColorChooser.showDialog(null , "Selecciona un color para el texto", Color.BLACK);
		texto.setForeground(selected);
	}
	
	/**
	 * Método main que crea y hace el Frame visible
	 * */
	public static void main(String[] args) {
		Saludo saludar = new Saludo();
		saludar.setVisible(true);
	}
}
